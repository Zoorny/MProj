CREATE TRIGGER USERS_ID_TRG
BEFORE INSERT
  ON USERS
FOR EACH ROW
  begin
    if :new.USER_ID is null then
      select users_seq.nextval into :new.USER_ID from dual;
    end if;
  end;
/
