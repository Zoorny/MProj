CREATE TRIGGER ALBUM_REVIEWS_TRG
BEFORE INSERT
  ON ALBUM_REVIEWS
FOR EACH ROW
  begin
    if :new.REVIEW_ID is null then
      select ALBUM_REVIEWS_SEQ.nextval into :new.REVIEW_ID from dual;
    end if;
  end;
/
